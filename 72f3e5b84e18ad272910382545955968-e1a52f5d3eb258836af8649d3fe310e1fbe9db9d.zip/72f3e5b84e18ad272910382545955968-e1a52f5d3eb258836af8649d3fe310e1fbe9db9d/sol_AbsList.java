package sol;
public abstract class AbsList implements IList {
// nothing to change?
    /*
     * TODO: modify the methods in AbsList so that elements of an AbsList are Ticket
     * objects instead of ints.
     */

    int eltCount;

    public AbsList(int size) {
        this.eltCount = size;
    }

    @Override
    public IList addFirst(Ticket elt) {
        return new NodeList(elt, this);
    }

    @Override
    public int size() {
        return this.eltCount;
    }
}
