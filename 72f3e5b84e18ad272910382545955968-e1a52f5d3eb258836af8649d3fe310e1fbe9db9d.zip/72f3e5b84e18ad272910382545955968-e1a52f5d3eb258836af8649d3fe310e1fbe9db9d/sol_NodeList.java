package sol;
public class NodeList extends AbsList {
    /*
     * TODO: modify the methods in NodeList so that elements of a NodeList are
     * Ticket objects instead of ints.
     */

    Ticket first;

    IList rest;

    public NodeList(Ticket fst, IList rst) {
        super(1 + rst.size()); // store the size of the list in the parent class
        this.first = fst;
        this.rest = rst;
    }


    @Override
    public boolean isEmpty() {
        return false;
    }

    @Override
    public IList remEltOnce(Ticket remelt) {
        if (remelt == this.first) {
            return this.rest;
        } else {
            return new NodeList(this.first, this.rest.remEltOnce(remelt));
        }
    }

    @Override
    public Ticket head() {
        return this.first;
    }

    @Override
    public IList tail() {
        return this.rest;
    }

    @Override
    public String toString() {
        return this.first + ", " + this.rest.toString();
    }

    // TODO: fill in the following method stubs

    @Override
    public Ticket findTicketByName(String name) {
        if (this.first.getName().equals(name)){
            return first;
        }
        else {
            return this.rest.findTicketByName(name);
        }
    }

    @Override
    public void updateTierOfTicket(String name, String tier) {
        findTicketByName(name).tier = tier;
    }

    @Override
    public IList removeTier(String tier) {
        if(this.first.tier.equals(tier)){
            return this.rest.removeTier(tier);
        }
        else{
            return new NodeList(this.first, this.rest.removeTier(tier));
        }
    }

    @Override
    public IList removeTicket(Ticket m) {
        if(!(this.first.equals(m))) {
            return new NodeList(this.first, this.rest.removeTicket(m));
        }
        else{
            return this.rest.removeTicket(m);
        }

    }

    @Override
    public IList shallowCopy() {
        IList NodeList = new NodeList(this.first, this.rest);
        return NodeList;
    }

    @Override
    public IList deepCopy() {
        Ticket copy = new Ticket(first.name, first.tier);
        return new NodeList(copy, rest.deepCopy());
    }
}
