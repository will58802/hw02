package sol;
public interface IList {

    /*
     * TODO: modify the method headers in IList so that elements of an IList are
     * Ticket objects instead of ints.
     */

    /**
     * Determines if a list is empty
     *
     * @return a boolean; true if the list is empty, false otherwise
     */
    public boolean isEmpty();

    /**
     * Construct a list with given element in first position
     *
     * @param elt -- the item to add to the list
     * @return the list with elt added as the first element
     */
    public IList addFirst(Ticket elt);

    /**
     * Remove first occurrence of item in a list
     *
     * @param elt -- the item to remove
     * @return the list with the first occurrence of elt removed
     */
    public IList remEltOnce(Ticket elt);

    /**
     * Produce the number of elements in the list
     *
     * @return an integer representing the number of items in the list
     */
    public int size();

    /**
     * Get the first element of the list
     *
     * @return the first element
     */
    public Ticket head();

    /**
     * Get the tail of the list
     *
     * @return the list without the first element
     */
    public IList tail();

    // TODO: Fill in this javadoc

    /**
     * @param name
     * @return
     */
    public Ticket findTicketByName(String name);

    // TODO: Fill in this javadoc

    /**
     * @param name
     * @param tier
     */
    public void updateTierOfTicket(String name, String tier);

    // TODO: Fill in this javadoc

    /**
     * @param tier
     * @return
     */
    public IList removeTier(String tier);

    // TODO: Fill in this javadoc

    /**
     * @param m
     * @return
     */
    public IList removeTicket(Ticket m);

    // TODO: Fill in this javadoc

    /**
     * @return
     */
    public IList shallowCopy();

    // TODO: Fill in this javadoc

    /**
     * @return
     */
    public IList deepCopy();
}
