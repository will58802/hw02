package sol;
public class Ticket {

    public String name;
    public String tier;

    /**
     * Constructor
     *
     * @param name -- a String representing the name associated with the ticket
     * @param tier
     */
    public Ticket(String name, String tier) {
        this.name = name;

        if (tier.equals("Platinum") || tier.equals("Diamond") || tier.equals("Gold")) {
            this.tier = tier;
        } else {
            throw new RuntimeException("Tier should be Platinum, Diamond, or " + "Gold");
        }
    }

    /**
     * @return the name associated with the ticket
     */
    public String getName() {
        return this.name;
    }

    /**
     * @return the tier associated with the ticket
     */
    public String getTier() {
        return this.tier;
    }

    /**
     * Sets the name of the ticket to the input name
     *
     * @param name -- new name of ticket
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Sets the tier of the ticket to the input tier
     *
     * @param tier -- new tier of ticket
     */
    public void setTier(String tier) {
        if (tier.equals("Platinum") || tier.equals("Diamond") || tier.equals("Gold")) {
            this.tier = tier;
        } else {
            throw new RuntimeException("Tier should be Platinum, Diamond, or Gold");
        }
    }

    /*
     * TODO: modify the equals method so that it also returns true if the input
     * object is a Ticket and has the same name and tier as this ticket.
     */
    @Override
    public boolean equals(Object obj) {
        // This is the generic format for an equals method. You will learn more about
        // this format in class. For now, all you have to worry about is the final
        // return statement.
        if (obj == this){
            return true;
        }

        if (!(obj instanceof Ticket)) {
            return false;
        }

        Ticket m = (Ticket) obj;

        if (m.name == this.name && m.tier == this.tier){
            return true;
        }
        // TODO: modifiy the following return statement. You don't want this to always
        // return false! You should be comparing this ticket to Ticket m.
        return false;
    }

    @Override
    public String toString() {
        return this.name + " (" + this.tier + ")";
    }
}
