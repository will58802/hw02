package sol;
public class EmptyList extends AbsList {

    /*
     * TODO: modify the methods in EmptyList so that elements of an EmptyList are
     * Ticket objects instead of ints.
     */

    public EmptyList() {
        super(0); // record that this list has size 0
    }

    @Override
    public boolean isEmpty() {
        return true;
    }

    @Override
    public IList remEltOnce(Ticket remelt) {
        return this;
    }

    @Override
    public Ticket head() {
        throw new RuntimeException("Attempt to take head of empty list");
    }

    @Override
    public IList tail() {
        throw new RuntimeException("Attempt to take tail of empty list");
    }

    @Override
    public Ticket findTicketByName(String name) {
        throw new RuntimeException("Could not find ticket for" + " " + name);
    }

    // TODO: fill in this method
    @Override
    public void updateTierOfTicket(String name, String tier) {
    }

    @Override
    public String toString() {
        return "empty";
    }

    // TODO: modify the following methods so that they work as intended
    @Override
    public IList removeTier(String tier) {
        return new EmptyList();
    }

    @Override
    public IList removeTicket(Ticket m) {
        return new EmptyList();
    }

    @Override
    public IList shallowCopy() {
        return this;
    }

    public NodeList EmptyList() {
        return null;
    }

    @Override
    public IList deepCopy() {
        return new EmptyList();
    }

}
