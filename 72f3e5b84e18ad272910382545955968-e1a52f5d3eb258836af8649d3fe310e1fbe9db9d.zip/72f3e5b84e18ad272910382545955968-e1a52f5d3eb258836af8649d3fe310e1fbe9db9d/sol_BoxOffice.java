package sol;

import tester.Tester;

public class BoxOffice{
    IList fullList; // contains all tickets (bought and awarded)
    IList compList; // contains only awarded tickets

    public BoxOffice(IList fullList, IList compList) {
        this.fullList = fullList;
        this.compList = compList;
    }

    // TODO: fill in the following method stubs
    /**
     * @param ticket
     */

    public void buyTicket(Ticket ticket) {
        fullList = fullList.addFirst(ticket);
    }

    /**
     * todo
     * 
     * @param ticket
     */
    public void awardTicket(Ticket ticket) {
        fullList = fullList.addFirst(ticket);
        compList = compList.addFirst(ticket);
    }

    public IList getFullList() {
        return this.fullList;
    }

    public IList getCompList() {
        return this.compList;
    }
}