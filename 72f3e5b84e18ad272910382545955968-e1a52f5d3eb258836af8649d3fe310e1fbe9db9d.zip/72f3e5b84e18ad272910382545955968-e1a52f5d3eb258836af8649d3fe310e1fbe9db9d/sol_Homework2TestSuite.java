package sol;
import tester.Tester;

import java.util.Arrays;

public class Homework2TestSuite {
    public Homework2TestSuite() {
    }

    public void testLists(Tester t) {
        Ticket lena = new Ticket("Lena Cohen", "Platinum");
        lena.setTier("Diamond");
        Ticket alvin = new Ticket("Alvin Chip", "Gold");
        Ticket will = new Ticket("Will Garry", "Gold");
        Ticket alex = new Ticket("Alex Sav", "Platinum");
        Ticket julian = new Ticket("Julian Leo", "Diamond");
        IList list1 = new EmptyList();
        list1 = list1.addFirst(lena);
        list1 = list1.addFirst(alvin);
        list1 = list1.addFirst(will);
        list1 = list1.addFirst(julian);
        // TODO: add Ticket objects to list1
        IList list2 = new EmptyList();
        // TODO: add Ticket objects to list2
        list2 = list2.addFirst(lena);
        list2 = list2.addFirst(will);
        list2 = list2.addFirst(alex);
        list2.updateTierOfTicket("Lena Cohen", "Platinum");
        t.checkExpect(list1.findTicketByName("Lena Cohen").getTier(), "Platinum"); //tests both findTicketByName and getTier()
        t.checkExpect(list2.findTicketByName("Lena Cohen").getTier(), "Platinum"); // changed in both with setTier()
        t.checkExpect(list1.findTicketByName("Lena Cohen"), new Ticket("Lena Cohen", "Platinum"));
        t.checkExpect(list1.shallowCopy(), list1);

        t.checkException(new RuntimeException("Could not find ticket for jenny"), list1, "findTicketByName", "jenny");
        IList deepCopylist1 = list1.deepCopy();
        IList deepCopyResult = new NodeList(julian, new NodeList(will, new NodeList(alvin, new NodeList(lena, new EmptyList()))));
        t.checkExpect(deepCopylist1, deepCopyResult);

        IList removeTicketResult = new NodeList(alex, new NodeList(will, new EmptyList()));
        t.checkExpect(list2.removeTicket(new Ticket("Lena Cohen", "Platinum")), removeTicketResult);

        IList removeTierResult = new NodeList(julian, new NodeList(will, new NodeList(alvin, new EmptyList())));
        t.checkExpect(list1.removeTier("Platinum"), removeTierResult);



    }

    public static void main(String[] args) {
        //System.out.println(list1);
        Tester.run(new Homework2TestSuite());
    }
}
